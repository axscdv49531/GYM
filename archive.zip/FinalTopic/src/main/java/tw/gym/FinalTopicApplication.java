package tw.gym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalTopicApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalTopicApplication.class, args);
	}

}
