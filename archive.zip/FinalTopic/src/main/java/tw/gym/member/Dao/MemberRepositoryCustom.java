package tw.gym.member.Dao;

import tw.gym.member.Model.MemberBean;

public interface MemberRepositoryCustom {
//	public MemberBean checkById(MemberBean memberBean, String id);
}
