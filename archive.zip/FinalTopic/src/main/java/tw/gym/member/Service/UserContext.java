//package tw.gym.member.Service;
//
//import tw.gym.member.Model.MemberBean;
//
//public interface UserContext {
//	MemberBean getCurrentUser();
//
//	void setCurrentUser(MemberBean user);
//}