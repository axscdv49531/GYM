package tw.gym.membercourse.model;

public interface Member_CourseRepositoryCustom {

public Member_Course insertMC(Member_Course mc);
	
	public Member_Course updateMC(Member_Course mc);

}
