package tw.fp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalTopicApplicationTests {

	@Test
	void contextLoads() {
	}

}
